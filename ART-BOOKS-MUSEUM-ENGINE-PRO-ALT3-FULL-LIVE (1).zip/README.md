# ART-BOOKS-MUSEUM-ENGINE-PRO — ALT3

Static Netlify-ready ART & BOOKS Digital Museum.

## Included
- Main HUB
- Gallery engine (ITMK 340 + MK 219 catalog positions)
- Universal viewer
- Books and documentation
- CIP catalogization links
- Official review links
- Certificate verification route
- Four certificate series: ITMK / MK / IT / D
- Stripe payment entry
- Humanitarian donation entry
- Future Lab
- Netlify redirects
- Existing uploaded PDFs preserved

## Important
The uploaded ZIP did not contain artwork JPG files, IT/D artwork files, mini-book PDFs, or a persistent database. The platform therefore creates the catalog structure without inventing missing files. When those assets are uploaded into the prepared folders, the gallery will automatically use them.

## Netlify
Deploy the repository root as-is. Publish directory: `.`.
