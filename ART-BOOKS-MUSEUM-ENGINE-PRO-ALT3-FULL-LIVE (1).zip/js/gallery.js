
const collections=[
  {key:'ITMK',label:'ITMK',count:340,folder:'assets/ITMK'},
  {key:'MK',label:'MK',count:219,folder:'assets/MK'},
  {key:'IT',label:'IT',count:0,folder:'assets/IT'},
  {key:'D',label:'DRACONIS',count:0,folder:'assets/D'}
];
let active='ALL';
const galleryGrid=document.getElementById('galleryGrid');

function renderGallery(){
  if(!galleryGrid)return;
  const q=(document.getElementById('gallerySearch')?.value||'').toLowerCase().trim();
  galleryGrid.innerHTML='';
  let total=0;
  collections.forEach(c=>{
    if(active!=='ALL' && active!==c.key)return;
    for(let i=1;i<=c.count;i++){
      const id=String(i).padStart(3,'0');
      const code=c.key+'-'+id;
      if(q && !code.toLowerCase().includes(q))continue;
      const card=document.createElement('article');
      card.className='art';
      const imgPath=`${c.folder}/${id}.jpg`;
      card.innerHTML=`<div class="art-media">${code}</div><div class="art-body"><b>${code}</b><br><small>Artwork record</small></div>`;
      const im=new Image();
      im.onload=()=>{card.querySelector('.art-media').outerHTML=`<img src="${imgPath}" alt="${code}">`};
      im.src=imgPath;
      card.onclick=()=>openModal(code,`<p><b>Collection:</b> ${c.label}</p><p><b>Catalog:</b> ${code}</p><div class="actions"><a class="btn goldbtn" href="viewer.html?id=${encodeURIComponent(code)}">Open Viewer</a><a class="btn" href="certificates.html?verify=${encodeURIComponent(code)}">Certificate</a></div>`);
      galleryGrid.appendChild(card); total++;
    }
  });
  const count=document.getElementById('galleryCount'); if(count) count.textContent=`${total} records displayed`;
}
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{active=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderGallery();});
  document.getElementById('gallerySearch')?.addEventListener('input',renderGallery);
  renderGallery();
});
