
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

function openModal(title, html){
  const m = $('#modal');
  if(!m) return;
  $('#modalTitle').textContent = title;
  $('#modalBody').innerHTML = html;
  m.classList.add('show');
}
function closeModal(){ const m=$('#modal'); if(m) m.classList.remove('show'); }
document.addEventListener('click',e=>{ if(e.target.id==='modal') closeModal(); });
document.addEventListener('keydown',e=>{if(e.key==='Escape') closeModal();});

function makeArtFallback(label){
  return `<div class="art-media">${label}</div>`;
}

function verifyCertificate(){
  const id = new URLSearchParams(location.search).get('verify');
  const box = $('#verification');
  if(!box) return;
  if(!id){
    box.innerHTML='<div class="card"><h2>Certificate Verification</h2><p>Enter a certificate ID or open a verification QR/link.</p><input id="verifyInput" class="search" placeholder="ART-ITMK-001"></div>';
    return;
  }
  box.innerHTML=`<div class="card"><h2>Certificate Verification</h2><p><span class="status">VERIFICATION PAGE REACHED</span></p><p><b>Certificate ID:</b> ${escapeHtml(id)}</p><p>This static museum verification page confirms that the verification link is structurally valid. Final ownership/authenticity records must be backed by the museum's authoritative certificate register.</p></div>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}

function downloadText(filename,text){
  const blob=new Blob([text],{type:'text/plain;charset=utf-8'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=filename; a.click(); URL.revokeObjectURL(a.href);
}
